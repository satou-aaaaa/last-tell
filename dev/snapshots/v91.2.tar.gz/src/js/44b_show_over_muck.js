/* ---------- 見せた札を捨て札の山より見せる（v88.2 レビュー） ---------- */
// 6人卓の縦で、ショーダウンで勝った左の席の見せた札（5♠）が捨て札の山（.muckpile）の下に隠れていた。
// ハンドの終わりに、見せた札と重なる山は隠す（山は飾り。札は勝ち負けの答えなので見えるほうを取る）。次のハンドで戻る。
function muckYield(){const m=document.querySelector('.felt .boardspot > .muckpile');if(!m)return;
  const on=!!(S&&S.handOver);if(!on||!m.children.length){m.classList.remove('mkyield');return}
  const R=e=>e.getBoundingClientRect(),shown=[...document.querySelectorAll('#felt .spot .hand:not(.folded):not(.muck) .card:not(.back):not(.slot)')].filter(e=>e.offsetParent).map(R);
  const hit=[...m.querySelectorAll('.muckcard')].map(R).some(a=>shown.some(b=>a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1));
  m.classList.toggle('mkyield',hit)}
LT.on('layout',()=>{try{muckYield()}catch(e){}});
