/* ---------- クセの読める範囲（改善提案 2026-10-18 §1 案A「台詞と印」、satou 2026-10-18 02:35Z 決定） ---------- */
// 自分を入れて3人以上が残っているハンドでクセの札が出たら、札に小さく「レイカだけ」と印を付ける（クセが教えるのは賭けた本人の手だけ）。
// 初めてのときだけ、師匠のひとこと（セーブに1回）。1対1は今まで通り。表示だけで、CPU・ボットの打ち方は変えない
// 仕様：research/クセの読める範囲_実装仕様.md
const READ_SCOPE_LINE_JA='クセは賭けた本人のことしか教えん。後ろにまだ人がいるぞ',READ_SCOPE_TAG_JA='{0}だけ',READ_SCOPE_TAG0_JA='この人だけ';
const RS_KEY='shisho-readscope';
if(typeof SAVE_KEYS!=='undefined'&&!SAVE_KEYS.includes(RS_KEY))SAVE_KEYS.push(RS_KEY);
// 第7章（ジンとの一騎打ち。本物のテルには触れない）・回想・物語の決めのハンドでは出さない
const rsOff=()=>!CFG||CFG.flashback||(CFG.ch&&(CFG.ch.script==='final'||(!CFG.ch.p2&&CFG.ch.no===7)))||!S||S.storyHand;
// 自分と本人のほかに、降りていない相手が1人以上
function rsMulti(p){const me=S.players[0];return !!me&&inHand(me)&&S.players.some(o=>o!==p&&!o.human&&inHand(o))}
// 印の名前は who()（まだ名乗っていない相手は見た目の呼び名。p.name をそのまま出すと名前がばれる）
// v94 レビュー 2：縦（520px 未満）は印を札と同じ行に並べる（2行だと下へ伸びて本人の目にかかる）。長い呼び名（青緑のスカーフ）は「この人だけ」に縮める
const rsNarrow=()=>innerWidth<520&&innerHeight>innerWidth;
function rsTag(p){const n=typeof who==='function'?who(p.name):'';return n&&!(rsNarrow()&&n.length>4)?READ_SCOPE_TAG_JA.replace('{0}',n):READ_SCOPE_TAG0_JA}
function rsLine(){if(S.rsSaid)return;const s=saveGet(RS_KEY,{v:1,seen:false})||{};if(s.seen)return;S.rsSaid=1;
  if(typeof uraLv==='function'&&uraLv()>=7)return;   // 裏の卓7段目からは師匠のひとことが出ないので、見たことにしない
  jinNote(READ_SCOPE_LINE_JA,0);saveSet(RS_KEY,{v:1,seen:true},1);
  // v94 レビュー 1：描き直しの中で決めるので、#senseiText はもう書かれている。もう一度描いて、このハンドのうちに出す（41_more_fun の mfBigFirst と同じ）。
  // 0 ハンド：1 にすると第4章のクセの手引きが2ハンド止まる
  setTimeout(()=>{try{render()}catch(e){}},0)}
LT.on('render',()=>{try{if(!S||!S.players)return;const off=S.handOver||rsOff();
  S.players.forEach((p,i)=>{const cb=$('cue'+i);if(!cb)return;
    const on=!off&&!!p.tell&&p.tell.meaning!=='none'&&rsMulti(p);   // クロウの手袋（meaning 'none'）には付けない
    let t=cb.querySelector('.rsOnly');   // 27_render は札の seq が変わると textContent を書き直すので、そのたびに付け直す
    if(on&&!t){t=document.createElement('small');t.className='rsOnly';cb.appendChild(t)}
    cb.classList.toggle('rsIn',on&&rsNarrow());
    if(t){if(t.hidden!==!on)t.hidden=!on;if(on){const x=rsTag(p);if(t.textContent!==x)t.textContent=x}}
    if(on)rsLine()})}catch(e){}});
LT.on('startHand',()=>{if(S)S.rsSaid=0});
// v94 レビュー 2：印の付いた札が本人の目の高さ（faceBox の上から 35〜55%）にかかるときは、札を目の上へ上げる（cuePlace の後）
function rsEyeAvoid(){const P=$('plates'),L=$('sayLayer');if(!P||!L||typeof faceBox!=='function')return;
  const pr=P.getBoundingClientRect(),z=pr.width/(P.offsetWidth||pr.width)||1,lr=L.getBoundingClientRect();
  P.querySelectorAll(':scope > .cue[data-bust]').forEach(cb=>{const t=cb.querySelector('.rsOnly');if(!t||t.hidden||!cb.offsetParent)return;
    const f=faceBox(+cb.dataset.bust);if(!f)return;const r=cb.getBoundingClientRect(),h=f.b-f.t,eT=lr.top+f.t+h*.35,eB=lr.top+f.t+h*.55;
    if(!(r.left<lr.left+f.r&&lr.left+f.l<r.right&&r.top<eB&&eT<r.bottom))return;
    const top=parseFloat(cb.style.top)||0;cb.style.top=Math.max(2,top-(r.bottom-eT+2)/z)+'px'})}
LT.on('layout',()=>{try{if(!$('game').hidden)rsEyeAvoid()}catch(e){}});
