/* ---------- 会話シーン ---------- */
let SC=null;
function playScene(ch,lines,done){
  SC={ch,lines,i:0,done};
  document.documentElement.style.setProperty('--venue',ch.color);
  SC.vh=`<span class="vchip">${chLab(ch)}　${esc(ch.title)}</span><span class="vn">${esc(ch.venue)}</span>`;$('venue').innerHTML=SC.vh;
  show('scene');renderLine();
}
function renderLine(){
  const l=SC.lines[SC.i];
  {const il=Array.isArray(l)&&l[2]&&l[2].il;$('scene').classList.toggle('il',!!il);
   if(il&&INTERLUDE[il]){if(SC.ilOn!==il){SC.ilOn=il;$('venue').innerHTML=`<span class="vchip">そのころ</span><span class="vn">${esc(INTERLUDE[il].place)}</span>`}ilSeen(il)}
   else if(SC.ilOn){SC.ilOn=0;if(SC.vh)$('venue').innerHTML=SC.vh}}
  if(l&&!Array.isArray(l)&&p2Line(l)){}
  else if(l&&l.part){setStage(null);$('stage').className='stage part';
    $('box').innerHTML=`<div class="partcard"><span>${esc(l.part)}</span><b>${esc(l.title)}</b></div>`}
  else if(l&&l.preview){const pv=PREVIEW[l.preview],nc=CHAPTERS[l.preview-1];
    $('stage').className='stage preview';$('stage').innerHTML=`<div class="portrait sil">${avatar(pv.boss)}</div><div class="sign">${esc(pv.sign)}</div>`;
    $('box').innerHTML=`<span class="lesson-tag">次回</span><div class="lesson"><div class="lt">第${nc.no}章　${esc(nc.title)}</div><p>「${esc(pv.line)}」</p></div>`}
  else if(l&&l.door){setStage(null);$('stage').className='stage part';const c=CHAPTERS[l.door-1],dd=DOOR_DAYS[l.door];
    $('box').innerHTML=`<div class="partcard door"><span>第${l.door}章</span><b>${esc(c.title)}</b>${dd?`<em>${esc(dd)}</em>`:''}</div>`}
  else if(l&&l.choice){$('box').innerHTML=`<div class="line narr">${esc(TEMPT.ask)}</div><div class="tchoice">${TEMPT.choices.map(c=>`<button class="ghost" data-tc="${c.id}">${esc(c.label)}</button>`).join('')}</div>`;
    $('box').querySelectorAll('[data-tc]').forEach(b=>b.onclick=e=>{e.stopPropagation();temptPick(b.dataset.tc)})}
  else if(l&&l.epilogue){setStage(null);
    $('box').innerHTML=`<span class="lesson-tag">その後</span><ul class="epi">${EPILOGUE.map(t=>`<li>${esc(t)}</li>`).join('')}</ul>`}
  else if(!Array.isArray(l)){
    setStage(SC.ch&&SC.ch.p2?'師匠':'ジン');
    $('box').innerHTML=`<span class="lesson-tag">${SC.ch&&SC.ch.p2?'二代目の教え':'師匠の教え'}</span><div class="lesson"><div class="lt">${esc(l.lesson)}</div><p>${esc(l.body)}</p></div>`;
  }else{
    const [who,text]=l,prev=SC.i>0&&Array.isArray(SC.lines[SC.i-1])?SC.lines[SC.i-1][0]:null;
    if(who&&who!==prev&&!(l[2]&&l[2].voice))setStage(who);
    else if(!who)setStage(null);
    const cute=rankOf(who)<3;
    const meta=l[2]||{};if(meta.brk)noteBreak(meta.brk);
    const mark=meta.mark&&loadCleared()>=7?`<div class="amark"><b>答え合わせ</b>${esc(meta.mark)}</div>`:'';
    $('box').innerHTML=`${who?`<span class="nametag${cute?' cute':''}">${esc(who==='師匠'?mentorName():who)}${l[2]&&l[2].voice?`<small class="voice">（${esc(l[2].voice)}）</small>`:''}${CHARS[who]&&!(l[2]&&l[2].voice)?`<span class="stars">${stars(rankOf(who))}</span>`:''}</span>`:''}<div class="line${who?'':' narr'}">${who?'「'+esc(text)+'」':esc(text)}</div>${mark}`;
  }
  p2After(l);
  $('btnAdv').textContent=SC.i===SC.lines.length-1?'進む':'次へ';$('btnAdv').hidden=!!(l&&l.choice&&!SC.picked);$('scene').classList.toggle('epil',!!(l&&l.epilogue));
}
function setStage(who){
  const st=$('stage');
  if(!who){st.className='stage';st.innerHTML='';return}
  st.className='stage '+(rankOf(who)>=3?'cool':'cute');
  st.innerHTML=`<div class="portrait">${avatar(who)}</div>`;
}
function advance(){setTimeout(fitScene,0);if(!SC)return;{const c=SC.lines[SC.i];if(c&&c.choice&&!SC.picked){temptPick('silent');return}}SC.i++;while(SC.i<SC.lines.length&&lineOff(SC.lines[SC.i]))SC.i++;if(SC.i>=SC.lines.length){const d=SC.done;SC=null;d();return}
  const l=SC.lines[SC.i];
  // 回想：会話の途中で1ハンドだけ打ち、終わったら続きに戻る
  if(l&&l.flashback){const sc=SC;SC=null;startFlashback(()=>{SC=sc;document.documentElement.style.setProperty('--venue',sc.ch.color);show('scene');advance()});return}
  renderLine()}
$('btnAdv').onclick=advance;
$('box').onclick=e=>{if(e.target.closest&&e.target.closest('[data-tc]'))return;const c=SC&&SC.lines[SC.i];if(c&&c.choice&&!SC.picked)return;advance()};
$('box').onkeydown=e=>{if(e.target!==e.currentTarget)return;if(e.key==='Enter'||e.key===' '){e.preventDefault();advance()}};
$('btnSkip').onclick=()=>{if(!SC)return;const d=SC.done;SC=null;d()};

// ===== 案6：噂（第4章から。章の前に、店の人や常連から聞ける） =====
// kind: true=正しい、old=古い噂（もう当てはまらない）、plant=わざと流された噂、flavor=手がかりではない
const RUMORS={
  4:[['ソウ','レイカさん、強いときは自分のチップをちらっと見るんです。……たぶん','true'],['ソウ','長く打っていると、レイカさんのクセは逆になるって、先輩が言ってました','true'],['常連','レイカは汗をかいたら勝負手だってさ','old']],
  5:[['テツ','ハヤトが急に動かなくなったら、要注意だ','true'],['テツ','あいつがこっちをじっと見てくるときは、たいてい嘘だ','true'],['常連','ハヤトは絶対にブラフしないって話だぜ','old']],
  6:[['カオル','クロウさん、汗をかいたら勝負手だって噂よ','plant'],['カオル','クロウさんが笑ったら……どうだったかしら。誰も確かめたことがないの','true'],['常連','本当に迷ったときだけ、白い手袋に触るって聞いたことがある','true']],
  7:[['店主','ジンさんの顎の傷のこと、誰も聞けないんだよ','flavor'],['ゲン','ジンさんはな、降りるときだけ、ちょっと笑うんだ','old'],['店主','昔のジンさんを知ってる人は、みんな同じことを言うよ。「手を見るな、顔を見ろ」ってね','flavor']]};
const RUMOR_KEY='shisho-rumor';
function loadRumor(){try{const o=JSON.parse(localStorage.getItem(RUMOR_KEY))||{};return o.heard&&typeof o.heard==='object'?o.heard:{}}catch(e){return{}}}
function rumorScene(ch,go){
  const R=RUMORS[ch.no];if(!R||ch.no<4)return go();
  const n=1+(regLevel(ch.no)>=1?1:0),pool=R.slice();const got=[];
  while(got.length<n&&pool.length)got.push(pool.splice(Math.floor(Math.random()*pool.length),1)[0]);
  const boss=ch.opps[0].name,h=loadRumor();h[boss]=h[boss]||[];got.forEach(r=>{if(!h[boss].includes(r[1]))h[boss].push(r[1])});
  try{localStorage.setItem(RUMOR_KEY,JSON.stringify({v:1,heard:h}))}catch(e){}
  playScene(ch,[['','店に入ると、噂話が耳に入ってきた。']].concat(got.map(r=>[r[0],r[1]])).concat([['ジン','噂は噂だ。最後は自分の目で確かめろ']]),go)}
// 主役と常連客を、主役が上側の中央寄りに来る順で並べる
function chSeats(ch){const P=ch.opps.map(o=>({...o}));if(!ch.extras)return P;const E=ch.extras.map(o=>({...o,extra:true}));return ch.seatPlan.map(k=>(k[0]==='p'?P:E)[+k.slice(1)])}
function startChapter(ch,skipIntro){
  if(ch&&ch.p2)return startP2(ch,skipIntro);
  ltTrack('chapter_start',{ch:ch.no});
  const go=()=>startGame({
    ch,nanori:!skipIntro,title:`第${ch.no}章　${ch.venue}`,blinds:ch.blinds,
    seats:[{name:'あなた',chips:ch.you,human:true}].concat(chSeats(ch)),
    goal:ch.goal,hint:ch.hint,refill:!!ch.refill,tells:!!ch.tells,house:ch.house||null,lamp:ch.lamp,bgm:ch.bgm,lore:ch.lore||'',levels:ch.levels||null,levelHands:ch.levelHands||0});
  skipIntro?go():playScene(ch,ch.intro,()=>rumorScene(ch,go));
}
// クリアした店で遊ぶ：その店の照明・音・相手で、フリー対戦のルール
function startStore(ch,skipEp){
  const ep=!skipEp&&nextAfter(ch.no);
  if(ep){const t=loadStory();t.ep[ep.id]=1;saveStory(t);return playScene(ch,ep.lines,()=>startStore(ch,true))}
  startGame({ch:null,store:ch.no,title:`フリー対戦（${ch.venue}）`,blinds:[1000,2000],goal:{type:'free'},hint:null,refill:false,tells:true,house:ch.house||null,lamp:ch.lamp,bgm:ch.bgm,
    seats:[{name:'あなた',chips:100000,human:true}].concat(ch.opps.map(o=>({...o,chips:100000})))});
}
function startFree(){
  ltTrack('free_start',{size:+$('freeSize').value||4});
  startGame({ch:null,title:'フリー対戦'+($('freeSize').value==='6'?'（6人卓）':'')+(HOUSE[$('freeRule').value]?'（'+HOUSE[$('freeRule').value].name+'）':''),blinds:[1000,2000],goal:{type:'free'},hint:null,refill:false,tells:true,house:$('freeRule').value||null,lamp:'#e2b65b',bgm:0,
    seats:[{name:'あなた',chips:100000,human:true},{name:'ケンジ',style:'normal',chips:100000},{name:'ミサキ',style:'normal',chips:100000}].concat(freeSeats())});
}
// 残りの席：クリアした店の常連＋タロウ（6人卓はテツ・ソウも）から毎回ランダム。第3章クリア後は、空いた席の1つに今日の船の客（6人卓は必ず、4人卓は2回に1回）
let freeShipN=0;
function freeSeats(){const six=$('freeSize').value==='6',rude=$('freeRude').checked,cl=loadCleared();
  const fill=[{name:'タロウ',style:'normal'}].concat(six?[{name:'テツ',style:'station'},{name:'ソウ',style:'liar2'}]:[]);
  const cand=Object.keys(MOBS).filter(k=>MOBS[k].store<=cl).map(k=>({name:k,style:MOBS[k].style})).concat(fill);
  let n=(six?3:1)-(rude?1:0),ship=null;const got=[];
  if(cl>=3&&n>0&&(six||(freeShipN++)%2===0)){const k=shipToday();ship={name:k,style:SHIP[k].style};n--}
  while(got.length<n&&cand.length)got.push(cand.splice(Math.floor(Math.random()*cand.length),1)[0]);
  fill.forEach(f=>{if(got.length<n&&!got.some(g=>g.name===f.name))got.push(f)});
  if(ship){got.splice(Math.floor(Math.random()*(got.length+1)),0,ship);shipMet(ship.name)}
  return(rude?[{name:'ゴウ',style:'rude'}]:[]).concat(got).map(o=>({...o,chips:100000}))
}
