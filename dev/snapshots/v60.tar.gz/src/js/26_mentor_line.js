/* ---------- 師匠のひとこと ---------- */
function isLatePos(){
  // ディーラー、またはディーラーの直前の席
  const live=S.players.map((p,i)=>i).filter(i=>!S.players[i].out);
  if(S.dealer===0)return true;
  return live.length>=3&&nextIdx(0,p=>!p.out)===S.dealer;
}
function senseiLine(){
  if(uraLv()>=7)return'';
  if(S.jinNote&&S.handNo<=S.jinNote.until)return S.jinNote.t;
  if(!CFG.hint||S.handOver||S.toAct!==0)return'';
  const me=S.players[0],toCall=S.currentBet-me.bet;
  if(CFG.hint==='hand'){
    if(S.street==='preflop'){
      const t=preTier(me.hand);
      if(t===2)return'いい手だ。勝負しろ。';
      if(t===1)return toCall<=BB()?'悪くない。安く入れるなら参加していい。':'悪くない手だが、大きく賭けられたら考えろ。';
      return toCall<=0?'弱い手だ。ただで見られるならチェックでいい。':'弱い手だ。降りろ。ゲンにくれてやれ。';
    }
    return isWeak(me.hand,S.board)?'何もできていない。ゲン相手にブラフは効かんぞ。':'役ができた。ゲンは降りない。しっかり賭けろ。';
  }
  if(CFG.hint==='position'){
    if(S.street!=='preflop')return'盗みはプリフロップで決めろ。ここからは手の強さで勝負だ。';
    const nobodyIn=S.players.every((p,i)=>i===0||p.bet<=BB())&&S.currentBet<=BB();
    if(isLatePos()&&nobodyIn)return'後ろの席で、誰も参加していない。手が弱くてもレイズで盗め。';
    if(isLatePos())return'誰かが先に参加した。盗むのはやめて、強い手だけで行け。';
    return preTier(me.hand)===2?'前の席だが、いい手だ。参加していい。':'前の席は不利だ。強い手以外は降りろ。';
  }
  if(CFG.hint==='tell'){
    if(S.revSaid===S.handNo+':'+S.street)return'……今のは、わざとだ。クセを信じすぎるな。';
    const t=S.players.map((q,j)=>({q,j})).filter(o=>!o.q.human&&o.q.tell&&o.q.tell.street===S.street&&!o.q.folded);
    if(t.length){
      const {q}=t[t.length-1];
      if(S.handNo>=8&&S.handNo%3)return'さっきのクセ、意味は覚えているか。自分で読め。';
      return q.tell.meaning==='strong'?`見たか。${q.name}が${CUE_LABEL[q.tell.cue]}。強いぞ。`
        :`見たか。${q.name}が${CUE_LABEL[q.tell.cue]}。ブラフかもしれん。`;
    }
    if(S.street==='preflop')return'相手の顔を見ろ。賭ける前に、何かが出る。';
    return toCall>0?'相手が賭けてきた。そのとき何が出ていたか思い出せ。':'手がなければ無理するな。チェックで様子を見ろ。';
  }
  if(CFG.hint==='bluff'){
    if(S.street==='preflop')return'フロップを見てから仕掛けろ。安く入れるなら参加していい。';
    const weak=isWeak(me.hand,S.board);
    if(weak&&toCall<=0)return'何もない。だが相手も迷っている。賭けてみろ。';
    if(weak)return'相手が打ってきた。今回は引け。';
    return'手ができた。普通に勝負しろ。';
  }
  return'';
}
