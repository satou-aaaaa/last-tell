/* ---------- 山札・役判定 ---------- */
function fullDeck(){const d=[];for(let s=0;s<4;s++)for(let r=2;r<=14;r++)d.push({r,s});return d}
function shuffle(a){for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
function eval5(cs){
  const rs=cs.map(c=>c.r).sort((a,b)=>b-a);
  const flush=cs.every(c=>c.s===cs[0].s);
  const uniq=[...new Set(rs)];
  let straightHigh=0;
  if(uniq.length===5){
    if(rs[0]-rs[4]===4)straightHigh=rs[0];
    else if(rs[0]===14&&rs[1]===5)straightHigh=5;
  }
  const cnt={};rs.forEach(r=>cnt[r]=(cnt[r]||0)+1);
  const groups=Object.entries(cnt).map(([r,n])=>[+r,n]).sort((a,b)=>b[1]-a[1]||b[0]-a[0]);
  const kick=groups.map(g=>g[0]);
  if(straightHigh&&flush)return[8,straightHigh];
  if(groups[0][1]===4)return[7,...kick];
  if(groups[0][1]===3&&groups[1][1]===2)return[6,...kick];
  if(flush)return[5,...rs];
  if(straightHigh)return[4,straightHigh];
  if(groups[0][1]===3)return[3,...kick];
  if(groups[0][1]===2&&groups[1][1]===2)return[2,...kick];
  if(groups[0][1]===2)return[1,...kick];
  return[0,...rs];
}
function cmp(a,b){for(let i=0;i<Math.max(a.length,b.length);i++){const d=(a[i]||0)-(b[i]||0);if(d)return d}return 0}
/* 5〜7枚から最強の5枚 */
function bestN(cs){
  let best=null;const n=cs.length,idx=[];
  (function rec(st,k){
    if(k===5){const s=eval5(idx.map(i=>cs[i]));if(!best||cmp(s,best)>0)best=s;return}
    for(let i=st;i<=n-(5-k);i++){idx.push(i);rec(i+1,k+1);idx.pop()}
  })(0,0);
  return best;
}
/* 5枚未満でも使える「ペア系の役の段階」 */
function groupCat(cs){
  if(cs.length===5)return eval5(cs)[0];
  const cnt={};cs.forEach(c=>cnt[c.r]=(cnt[c.r]||0)+1);
  const v=Object.values(cnt).sort((a,b)=>b-a);
  if(v[0]===4)return 7;if(v[0]===3)return 3;if(v[0]===2&&v[1]===2)return 2;if(v[0]===2)return 1;return 0;
}
/* 自分の2枚が役に絡んでいない＝実質「何もない」 */
function isWeak(hand,board){
  if(board.length<3)return false;
  const mine=bestN(hand.concat(board))[0];
  return mine===0||mine<=groupCat(board);
}
function handName(s){if(s[0]===8&&s[1]===14)return'ロイヤルフラッシュ';return HAND_JP[s[0]]}
function preTier(h){
  const [a,b]=[h[0].r,h[1].r].sort((x,y)=>y-x),suited=h[0].s===h[1].s;
  if(a===b)return a>=7?2:1;
  if(a===14&&b>=11)return 2;
  if(a===13&&b===12)return 2;
  if(a===14&&suited)return 1;
  if(a>=10&&b>=10)return 1;
  if(suited&&a-b<=2&&b>=5)return 1;
  if(a===14&&b>=9)return 1;
  return 0;
}
