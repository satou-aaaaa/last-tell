/* ---------- 音（WebAudio・最初はオフ） ---------- */
const Sound=(()=>{
  let ac=null,master=null,loop=0,cur=-1,paused=false,riffle=0;
  const CH=[ // 店ごとの和音（周波数）と間隔
    {ch:[[110,164.8,220,277.2],[98,146.8,196,246.9]],gap:4200,wave:'triangle'},             // フリー
    {ch:[[73.4,110,146.8,174.6],[65.4,98,130.8,164.8]],gap:5200,wave:'triangle'},           // 錨亭：低くて暗い
    {ch:[[82.4,123.5,164.8,207.7],[87.3,130.8,174.6,220]],gap:4800,wave:'sine'},            // 銀の扉：静か
    {ch:[[98,146.8,185,233.1,293.7],[87.3,130.8,164.8,207.7,261.6]],gap:3600,wave:'triangle'},// 月影：ジャズの和音
    {ch:[[110,164.8,207.7,246.9,329.6],[123.5,185,233.1,277.2,349.2]],gap:4400,wave:'sine'},
    {ch:[[61.7,92.5,123.5,146.8],[55,82.4,110,130.8]],gap:4600,wave:'triangle'},          // 地下：重く暗い
    {ch:[[87.3,130.8,174.6,220,261.6],[98,146.8,196,246.9,293.7]],gap:5000,wave:'sine'},   // 王冠：広く静か
    {ch:[[73.4,110,146.8,185],[82.4,123.5,164.8,207.7]],gap:5600,wave:'sine'},              // 錨亭、閉店後// 天空：明るく上品
  ];
  function ctx(){if(!ac){const A=window.AudioContext||window.webkitAudioContext;if(!A)return null;ac=new A();master=ac.createGain();master.gain.value=.5;master.connect(ac.destination)}
    if(ac.state==='suspended')ac.resume();return ac}
  function tone(f,dur,vol,wave,at){
    const c=ctx();if(!c)return;const t=c.currentTime+(at||0);
    const o=c.createOscillator(),g=c.createGain();o.type=wave||'sine';o.frequency.value=f;
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(vol,t+Math.min(.6,dur/3));g.gain.exponentialRampToValueAtTime(.0001,t+dur);
    o.connect(g);g.connect(master);o.start(t);o.stop(t+dur+.05);
  }
  function click(f,vol){const c=ctx();if(!c)return;const t=c.currentTime;
    const b=c.createBuffer(1,Math.floor(c.sampleRate*.04),c.sampleRate),d=b.getChannelData(0);for(let k=0;k<d.length;k++)d[k]=(Math.random()*2-1)*Math.pow(1-k/d.length,3);
    const s=c.createBufferSource(),bp=c.createBiquadFilter(),g=c.createGain();bp.type='bandpass';bp.frequency.value=f;bp.Q.value=4;g.gain.value=vol;
    s.buffer=b;s.connect(bp);bp.connect(g);g.connect(master);s.start(t)}
  function play(){const set=CH[cur];if(!set)return;const k=Math.floor(Date.now()/set.gap)%set.ch.length;
    set.ch[k].forEach((f,j)=>tone(f,set.gap/1000*1.1,.035-j*.004,set.wave,j*.03))}
  return{
    sfx(kind){if(!SETTINGS.sound||paused)return;
      if(kind==='chip'){click(3200,.5);setTimeout(()=>click(2600,.35),60)}
      else if(kind==='card')click(1400,.35);
      else if(kind==='turn'){tone(880,.08,.05,'sine');tone(1320,.08,.04,'sine',.07)}
      else if(kind==='win'){[523,659,784].forEach((f,j)=>tone(f,.5,.06,'triangle',j*.08))}},
    // 静まり返る：BGMを止め、チップをいじる音だけを鳴らす
    hush(on){clearInterval(riffle);riffle=0;
      if(on){clearInterval(loop);loop=0;if(SETTINGS.sound&&!paused)riffle=setInterval(()=>{if(!SETTINGS.sound||paused)return;click(3000+Math.random()*600,.18);setTimeout(()=>click(2700,.12),70)},650)}
      else if(SETTINGS.sound&&!paused&&cur>=0&&!loop&&!$('game').hidden)this.bgm(cur)},
    murmur(loud){if(!SETTINGS.sound||paused)return;const c=ctx();if(!c)return;const t=c.currentTime,dur=loud?1.4:.8;
      const b=c.createBuffer(1,Math.floor(c.sampleRate*dur),c.sampleRate),d=b.getChannelData(0);for(let k=0;k<d.length;k++)d[k]=(Math.random()*2-1)*Math.sin(Math.PI*k/d.length);
      const s=c.createBufferSource(),lp=c.createBiquadFilter(),g=c.createGain();lp.type='lowpass';lp.frequency.value=600;g.gain.setValueAtTime(.14,t);
      if(loud){g.gain.linearRampToValueAtTime(.32,t+.2);g.gain.setValueAtTime(.32,t+.8);g.gain.linearRampToValueAtTime(.12,t+1.1)}
      s.buffer=b;s.connect(lp);lp.connect(g);g.connect(master);s.start(t)},
    heart(){if(!SETTINGS.sound||paused)return;tone(58,.18,.3,'sine');tone(52,.2,.22,'sine',.16)},
    thud(){if(!SETTINGS.sound||paused)return;tone(46,.6,.32,'sine');click(900,.4)},
    bgm(n){cur=n;clearInterval(loop);if(!SETTINGS.sound||paused||!CH[n])return;play();loop=setInterval(play,CH[n].gap)},
    stop(){clearInterval(loop);loop=0},
    // 裏に回ったときや広告の表示中は止め、戻ったら再開する
    pause(){paused=true;clearInterval(loop);loop=0;clearInterval(riffle);riffle=0;if(ac&&ac.state==='running')ac.suspend()},
    resume(){if(!paused)return;paused=false;if(ac&&SETTINGS.sound)ac.resume();if(SETTINGS.sound&&cur>=0&&!$('game').hidden)this.bgm(cur)},
  };
})();
document.addEventListener('visibilitychange',()=>document.hidden?Sound.pause():Sound.resume());
window.Sound=Sound; // C-5：アプリ側が広告の前後で Sound.pause()／Sound.resume() を呼ぶ
function renderSound(){$('btnSound').textContent='音：'+(SETTINGS.sound?'オン':'オフ')}
