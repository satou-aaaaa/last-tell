// 改善提案 2026-10-15b（ゲームをもっと面白く）案1・案2 の英語。research/改善提案_2026-10-15b_データ.js から
Object.assign(EN_DICT,{
"でかい勝負ほど、人は顔を隠せない":"The bigger the pot, the less a face can hide.",
"……チップを見た。前に見たときは、強い手だった":"...A glance at the chips. Last time, that was a strong hand.",
"……チップを見た。あのときは、何もなかった":"...A glance at the chips. Last time, there was nothing behind it.",
"……チップを見た。前は、特に意味はなかった":"...A glance at the chips. Last time, it meant nothing.",
"……指が止まった。前に見たときは、強い手だった":"...Frozen. Last time, that was a strong hand.",
"……指が止まった。あのときは、何もなかった":"...Frozen. Last time, there was nothing behind it.",
"……指が止まった。前は、特に意味はなかった":"...Frozen. Last time, it meant nothing.",
"……また笑った。前に見たときは、強い手だった":"...That smile again. Last time, it was a strong hand.",
"……また笑った。あのときは、何もなかった":"...That smile again. Last time, there was nothing behind it.",
"……また笑った。前は、特に意味はなかった":"...That smile again. Last time, it meant nothing.",
"……こっちを見ている。前に見たときは、強い手だった":"...Staring at me. Last time, that was a strong hand.",
"……こっちを見ている。あのときは、何もなかった":"...Staring at me. Last time, there was nothing behind it.",
"……こっちを見ている。前は、特に意味はなかった":"...Staring at me. Last time, it meant nothing.",
"……口数が増えた。前に見たときは、強い手だった":"...Talking more. Last time, that was a strong hand.",
"……口数が増えた。あのときは、何もなかった":"...Talking more. Last time, there was nothing behind it.",
"……口数が増えた。前は、特に意味はなかった":"...Talking more. Last time, it meant nothing.",
"……すぐ賭けた。前に見たときは、強い手だった":"...An instant bet. Last time, that was a strong hand.",
"……すぐ賭けた。あのときは、何もなかった":"...An instant bet. Last time, there was nothing behind it.",
"……すぐ賭けた。前は、特に意味はなかった":"...An instant bet. Last time, it meant nothing.",
"……汗をかいている。前に見たときは、強い手だった":"...Sweating. Last time, that was a strong hand.",
"……汗をかいている。あのときは、何もなかった":"...Sweating. Last time, there was nothing behind it.",
"……汗をかいている。前は、特に意味はなかった":"...Sweating. Last time, it meant nothing.",
"……前と同じとは、限らない":"...It might not mean the same thing this time."
});
// 案5 読み勝ちの見返し
Object.assign(EN_DICT,{"この章の読み":"Your read of the chapter","あなたはコールした":"You called.","あなたは降りた":"You folded.","タップでとばす":"Tap to skip"});
