/* ---------- 見せた札を捨て札の山より見せる（v88.2 レビュー） ---------- */
// 6人卓の縦で、ショーダウンで勝った左の席の見せた札（5♠）が捨て札の山（.muckpile）の下に隠れていた。
// ハンドの終わりに、見せた札と重なる山は隠す（山は飾り。札は勝ち負けの答えなので見えるほうを取る）。次のハンドで戻る。
function muckYield(){const m=document.querySelector('.felt .boardspot > .muckpile');if(!m)return;
  const on=!!(S&&S.handOver);if(!on||!m.children.length){m.classList.remove('mkyield');return}
  const R=e=>e.getBoundingClientRect(),shown=[...document.querySelectorAll('#felt .spot .hand:not(.folded):not(.muck) .card:not(.back):not(.slot)')].filter(e=>e.offsetParent).map(R);
  const hit=[...m.querySelectorAll('.muckcard')].map(R).some(a=>shown.some(b=>a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1));
  m.classList.toggle('mkyield',hit)}
LT.on('layout',()=>{try{muckYield()}catch(e){}});
// 見せた札が場札に重なるときは、その席の札を上へ逃がす（v91.2 レビュー：6人卓の縦で右の席の見せた札が川の札の上半分にかかった）
// ハンドの終わりだけ。場札は動かさない（みんなの札なので）。次のハンドで戻す
function showYieldBoard(){const hands=[...document.querySelectorAll('#felt .spot .hand')];
  const on=!!(S&&S.handOver);
  hands.forEach(h=>{if(h.dataset.syb&&(!on||h.classList.contains('folded')||h.classList.contains('muck'))){h.style.translate='';h.style.scale='';delete h.dataset.syb}});
  if(!on)return;
  const R=e=>e.getBoundingClientRect(),board=[...document.querySelectorAll('#boardCards .card:not(.slot)')].filter(e=>e.offsetParent).map(R).filter(r=>r.width>2);if(!board.length)return;
  let moved=0;
  hands.forEach(h=>{if(h.classList.contains('folded')||h.classList.contains('muck'))return;
    const cs=[...h.querySelectorAll('.card:not(.back):not(.slot)')].filter(e=>e.offsetParent);if(!cs.length)return;
    h.style.translate='';h.style.scale='';
    let need=0;cs.map(R).forEach(a=>board.forEach(b=>{if(!(a.left<b.right-1&&b.left<a.right-1&&a.top<b.bottom-1&&b.top<a.bottom-1))return;
      const d=a.top+a.bottom<b.top+b.bottom?-(a.bottom-b.top+3):b.bottom-a.top+3;if(Math.abs(d)>Math.abs(need))need=d}));   // 場札より上にある札は上へ、下にある札は下へ
    // v96 レビュー：5人卓では上へ逃がすと名札（と D）に札の数字の角が隠れた。名札の下から場札の上までに収まらないときは、札を縮めて収める
    let sc=1;{const sp=h.closest('.spot'),pl=sp&&$('plate'+sp.id.replace('spot','')),q=pl&&pl.getClientRects().length&&R(pl).width>2?R(pl):null;
      if(q){const rs=cs.map(R),top=Math.min(...rs.map(r=>r.top)),bot=Math.max(...rs.map(r=>r.bottom)),bt=Math.min(...board.map(r=>r.top)),L=Math.min(...rs.map(r=>r.left)),Rt=Math.max(...rs.map(r=>r.right));
        if(L<q.right&&q.left<Rt&&top<bt&&top+need<q.bottom+1&&q.bottom<bt){const room=bt-3-(q.bottom+1),f=room/(bot-top);if(f>=.6){sc=Math.min(1,f);need=q.bottom+1-top}}}}   // 0.6倍でも入らないときは縮めない（場札にはかけず、前のとおり名札の側へ逃がす）
    if(!need&&sc===1){delete h.dataset.syb;return}
    const k=h.offsetHeight?R(h).height/h.offsetHeight:1;
    h.style.transformOrigin=sc<1?'50% 0':'';h.style.scale=sc<1?sc.toFixed(3):'';
    h.style.translate=`0 ${Math.round(need/(k||1))}px`;h.dataset.syb='1';moved=1});
  // 札を動かしたら、勝ち負けの札（.vfres）も置き直す（v96.1 CI：6人卓の縦で、動いた見せた札に .vfres がかかった）
  if(moved){const v=document.querySelector('#table .vfres');if(v&&v._place)try{v._place()}catch(e){}}}
LT.on('layout',()=>{try{showYieldBoard()}catch(e){}
  // 見せた札は開く動きのあとで場所が決まる。layout が来ないこともあるので、ハンドの終わりに2回だけ測り直す（v96 レビュー：PC で名札に札の角が残った）
  try{if(S&&S.handOver&&S._sybT!==S.handNo){S._sybT=S.handNo;[700,1600].forEach(t=>setTimeout(()=>{try{if(S&&S.handOver)showYieldBoard()}catch(e){}},t))}}catch(e){}});
