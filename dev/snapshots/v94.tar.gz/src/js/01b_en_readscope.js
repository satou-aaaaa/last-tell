// クセの読める範囲（js/50_read_scope.js）の英語
Object.assign(EN_DICT,{'クセは賭けた本人のことしか教えん。後ろにまだ人がいるぞ':"A tell only speaks for the one who bet. Someone's still behind them.",'この人だけ':'this one only'});
EN_TPL.push(['{0}だけ','{0} only']);
