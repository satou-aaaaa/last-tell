/* ---------- クセの読める範囲（改善提案 2026-10-18 §1 案A「台詞と印」、satou 2026-10-18 02:35Z 決定） ---------- */
// 自分を入れて3人以上が残っているハンドでクセの札が出たら、札に小さく「レイカだけ」と印を付ける（クセが教えるのは賭けた本人の手だけ）。
// 初めてのときだけ、師匠のひとこと（セーブに1回）。1対1は今まで通り。表示だけで、CPU・ボットの打ち方は変えない
// 仕様：research/クセの読める範囲_実装仕様.md
const READ_SCOPE_LINE_JA='クセは賭けた本人のことしか教えん。後ろにまだ人がいるぞ',READ_SCOPE_TAG_JA='{0}だけ',READ_SCOPE_TAG0_JA='この人だけ';
const RS_KEY='shisho-readscope';
if(typeof SAVE_KEYS!=='undefined'&&!SAVE_KEYS.includes(RS_KEY))SAVE_KEYS.push(RS_KEY);
// 第7章（ジンとの一騎打ち。本物のテルには触れない）・回想・物語の決めのハンドでは出さない
const rsOff=()=>!CFG||CFG.flashback||(CFG.ch&&(CFG.ch.script==='final'||(!CFG.ch.p2&&CFG.ch.no===7)))||!S||S.storyHand;
// 自分と本人のほかに、降りていない相手が1人以上
function rsMulti(p){const me=S.players[0];return !!me&&inHand(me)&&S.players.some(o=>o!==p&&!o.human&&inHand(o))}
// 印の名前は who()（まだ名乗っていない相手は見た目の呼び名。p.name をそのまま出すと名前がばれる）
function rsTag(p){const n=typeof who==='function'?who(p.name):'';return n?READ_SCOPE_TAG_JA.replace('{0}',n):READ_SCOPE_TAG0_JA}
function rsLine(){if(S.rsSaid)return;const s=saveGet(RS_KEY,{v:1,seen:false})||{};if(s.seen)return;S.rsSaid=1;
  if(typeof uraLv==='function'&&uraLv()>=7)return;   // 裏の卓7段目からは師匠のひとことが出ないので、見たことにしない
  jinNote(READ_SCOPE_LINE_JA,1);saveSet(RS_KEY,{v:1,seen:true},1)}
LT.on('render',()=>{try{if(!S||!S.players)return;const off=S.handOver||rsOff();
  S.players.forEach((p,i)=>{const cb=$('cue'+i);if(!cb)return;
    const on=!off&&!!p.tell&&p.tell.meaning!=='none'&&rsMulti(p);   // クロウの手袋（meaning 'none'）には付けない
    let t=cb.querySelector('.rsOnly');   // 27_render は札の seq が変わると textContent を書き直すので、そのたびに付け直す
    if(on&&!t){t=document.createElement('small');t.className='rsOnly';cb.appendChild(t)}
    if(t){if(t.hidden!==!on)t.hidden=!on;if(on){const x=rsTag(p);if(t.textContent!==x)t.textContent=x}}
    if(on)rsLine()})}catch(e){}});
LT.on('startHand',()=>{if(S)S.rsSaid=0});
