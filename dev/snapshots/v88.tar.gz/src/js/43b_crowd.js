/* ---------- 人だかり（改善提案 2026-10-15b 案4。satou 2026-10-17「すべて対応」で 1.0 に。research/改善提案_2026-10-15b_実装仕様.md） ---------- */
// オールインがコールされたとき（S.runout）、またはリバーでポットが 40BB 以上のとき、卓の奥に影の立ち姿が2〜3人並ぶ。
// 影は相手の上半身（.busts）より奥の層なので、札・名札・ボタンには重ならない。形と色は店の奥の客の影（41_live_look.js 案5）と同じ。
// 結果が出たら「おお……」系の小さな声が1行出て、影が消える。人だかりが出たハンドの次は、隣の卓の声を出さない。
// 第7章の最後の手と顔のアップ中は、影を左右の端だけに置く。動きは opacity と transform だけ（フィルター禁止）。回想では出さない。
const CROWD={potBB:40,afterMs:1800,lines:['おお……','……今の、見たか','すげえな']};
function crowdEl(){const tb=$('table'),rm=tb&&tb.querySelector('.room');if(!rm)return null;let c=tb.querySelector('.ltcrowd');
  if(!c){c=document.createElement('div');c.className='ltcrowd';c.setAttribute('aria-hidden','true');c.innerHTML='<i class="cr1"></i><i class="cr2"></i><i class="cr3"></i><b></b>';
}
  if(c.previousElementSibling!==rm)rm.after(c);   // 店の奥（.room）のすぐ上、相手の上半身より奥。カメラの層（#cam）ができると .room が移るので、毎回そろえる
  return c}
const crowdEdge=()=>(S.finalHand&&CFG.ch&&!CFG.ch.p2&&CFG.ch.no===7)||(typeof camState!=='undefined'&&camState&&camState.kind&&camState.kind!=='wide');
function crowdHide(){const c=document.querySelector('#table .ltcrowd');if(c){c.classList.remove('cr-on','cr-say');clearTimeout(c._t)}}
LT.on('startHand',()=>{try{crowdHide()}catch(e){}});
LT.on('render',()=>{try{
  if(!S||!S.players||CFG.flashback||S.handOver)return;
  const c0=document.querySelector('#table .ltcrowd');if(c0&&c0.classList.contains('cr-on'))c0.classList.toggle('cr-edge',crowdEdge());
  if(S.crowdHand===S.handNo)return;
  if(!(S.runout||(S.street==='river'&&potTotal()>=CROWD.potBB*BB())))return;
  S.crowdHand=S.handNo;S.nvNext=Math.max(S.nvNext||0,S.handNo+2);   // このハンドの終わりと次のハンドの終わりは、隣の卓の声を出さない
  const c=crowdEl();if(!c)return;c.classList.toggle('cr-n3',LT.rand()<.5);c.classList.toggle('cr-edge',crowdEdge());c.classList.toggle('cr-still',reducedMotion());
  c.classList.remove('cr-say');void c.offsetWidth;c.classList.add('cr-on')}catch(e){}});
LT.on('endHand',()=>{try{
  const c=document.querySelector('#table .ltcrowd');if(!c||!c.classList.contains('cr-on')||S.crowdHand!==S.handNo)return;
  const t=CROWD.lines[Math.floor(LT.rand()*CROWD.lines.length)];c.querySelector('b').textContent=t;c.classList.add('cr-say');
  if(reducedMotion())log(t);
  clearTimeout(c._t);c._t=setTimeout(()=>crowdHide(),CROWD.afterMs*(typeof SPEED==='function'?Math.max(.6,SPEED()):1))}catch(e){}});
